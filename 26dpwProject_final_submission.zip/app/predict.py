from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from sklearn.ensemble import GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder

from app.charts import chart_layout, empty_chart
from app.config import AMBER, BLUE, GREEN, MONTHS, PURPLE, ROSE, TEAL
from app.metrics import money


@st.cache_resource(show_spinner="Training prediction models…")
def _build_models(_df: pd.DataFrame):
    train = _df[
        (_df["budget"] > 0)
        & (_df["revenue"] > 0)
        & _df["roi"].notna()
        & _df["runtime"].notna()
        & (_df["runtime"] > 0)
        & _df["release_month"].notna()
        & _df["primary_genre"].notna()
        & (_df["primary_genre"] != "Unknown")
    ].copy()

    genre_enc = OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1)
    train["genre_enc"] = genre_enc.fit_transform(train[["primary_genre"]])
    train["log_budget"] = np.log1p(train["budget"])

    FEATURES = ["log_budget", "genre_enc", "release_month", "runtime"]
    X = train[FEATURES].values.astype(float)

    roi_cap = train["roi"].quantile(0.97)
    y_rev = np.log1p(train["revenue"].values)
    y_roi = train["roi"].clip(upper=roi_cap).values
    y_profit = (train["revenue"] > train["budget"]).astype(int).values

    params = dict(
        n_estimators=300, learning_rate=0.05, max_depth=4,
        subsample=0.8, min_samples_leaf=10, random_state=42,
    )
    rev_model = GradientBoostingRegressor(**params).fit(X, y_rev)
    roi_model = GradientBoostingRegressor(**params).fit(X, y_roi)
    profit_model = GradientBoostingClassifier(**params).fit(X, y_profit)

    return rev_model, roi_model, profit_model, genre_enc, FEATURES


def predict_movie(df: pd.DataFrame, budget: float, genre: str, release_month: int, runtime: int) -> dict:
    rev_model, roi_model, profit_model, genre_enc, FEATURES = _build_models(df)

    genre_code = genre_enc.transform([[genre]])[0][0]
    X = np.array([[np.log1p(budget), genre_code, release_month, runtime]])

    pred_revenue = float(np.expm1(rev_model.predict(X)[0]))
    pred_roi = float(roi_model.predict(X)[0])
    profit_prob = float(profit_model.predict_proba(X)[0][1])

    return {
        "predicted_revenue": pred_revenue,
        "predicted_roi": pred_roi,
        "profit_probability": profit_prob,
        "lower_revenue": pred_revenue * 0.72,
        "upper_revenue": pred_revenue * 1.42,
    }


def _comparable_scatter(df: pd.DataFrame, budget: float, genre: str, pred_revenue: float) -> go.Figure:
    comps = df[
        (df["budget"] >= budget * 0.5)
        & (df["budget"] <= budget * 1.5)
        & (df["primary_genre"] == genre)
        & (df["revenue"] > 0)
    ]
    if comps.empty:
        comps = df[(df["budget"] >= budget * 0.5) & (df["budget"] <= budget * 1.5) & (df["revenue"] > 0)]

    fig = go.Figure()
    if not comps.empty:
        fig.add_trace(go.Scatter(
            x=comps["budget"], y=comps["revenue"],
            mode="markers", name="Historical",
            text=comps["title"],
            hovertemplate="<b>%{text}</b><br>Budget: $%{x:,.0f}<br>Revenue: $%{y:,.0f}<extra></extra>",
            marker=dict(size=7, color=BLUE, opacity=0.65, line=dict(width=0)),
        ))

    fig.add_trace(go.Scatter(
        x=[budget], y=[pred_revenue],
        mode="markers+text", name="Prediction",
        text=["Your Movie"], textposition="top center",
        textfont=dict(color=AMBER, size=12, family="Inter"),
        hovertemplate="<b>Predicted</b><br>Budget: $%{x:,.0f}<br>Revenue: $%{y:,.0f}<extra></extra>",
        marker=dict(size=14, color=AMBER, symbol="star", line=dict(width=1.5, color="#fff")),
    ))

    fig.update_layout(**chart_layout(320))
    fig.update_xaxes(title="Budget (USD)")
    fig.update_yaxes(title="Revenue (USD)")
    return fig


def _roi_histogram(df: pd.DataFrame, genre: str) -> go.Figure:
    genre_df = df[(df["primary_genre"] == genre) & df["roi"].notna() & (df["roi"] > 0)].copy()
    if genre_df.empty:
        return empty_chart(f"No ROI data for genre: {genre}", 280)

    cap = genre_df["roi"].quantile(0.96)
    plot_df = genre_df[genre_df["roi"] <= cap]

    fig = go.Figure()
    fig.add_trace(go.Histogram(
        x=plot_df["roi"], nbinsx=35,
        marker=dict(color=PURPLE, opacity=0.80, line=dict(color="#07111f", width=0.6)),
        hovertemplate="ROI: %{x:.1f}x<br>Count: %{y}<extra></extra>",
        name="Historical ROI",
    ))
    fig.update_layout(**chart_layout(280))
    fig.update_xaxes(title=f"ROI (x)  ·  {genre}")
    fig.update_yaxes(title="Number of Films")
    return fig


def _comparable_table(df: pd.DataFrame, budget: float, genre: str) -> pd.DataFrame:
    valid = df[
        (df["budget"] > 0) & (df["revenue"] > 0)
        & (df["primary_genre"] == genre) & df["roi"].notna()
    ].copy()
    if valid.empty:
        valid = df[(df["budget"] > 0) & (df["revenue"] > 0) & df["roi"].notna()].copy()

    valid["budget_diff"] = (valid["budget"] - budget).abs()
    top5 = valid.nsmallest(5, "budget_diff")[
        ["title", "year", "budget", "revenue", "roi", "avg_rating", "primary_genre"]
    ].copy()
    top5 = top5.rename(columns={
        "title": "Title", "year": "Year", "budget": "Budget",
        "revenue": "Revenue", "roi": "ROI", "avg_rating": "Rating", "primary_genre": "Genre",
    })
    top5["Budget"] = top5["Budget"].apply(money)
    top5["Revenue"] = top5["Revenue"].apply(money)
    top5["ROI"] = top5["ROI"].apply(lambda v: f"{v:.2f}x" if pd.notna(v) else "—")
    top5["Rating"] = top5["Rating"].apply(lambda v: f"{v:.1f}" if pd.notna(v) else "—")
    return top5.reset_index(drop=True)


def _pred_kpi(label: str, value: str, sub: str, accent: str) -> str:
    return (
        f'<div class="kpi-card" style="--accent:{accent}">'
        f'<div class="kpi-label">{label}</div>'
        f'<div class="kpi-value">{value}</div>'
        f'<div class="kpi-foot"><div class="kpi-change neu" style="font-size:11px">{sub}</div></div>'
        f"</div>"
    )


def render_predict_view(df: pd.DataFrame) -> None:
    from app.components import render_chart_panel

    st.markdown(
        '<div style="text-align:center;margin:0 0 1.4rem">'
        '<div style="font-size:28px;font-weight:900;color:#f7fbff;letter-spacing:-.02em;margin-bottom:.35rem">'
        "🎬 Movie Revenue &amp; ROI Predictor</div>"
        '<div style="font-size:13px;color:#9aa9bd;">Input your film parameters to get an AI-powered box office forecast</div>'
        "</div>",
        unsafe_allow_html=True,
    )

    valid_genres = sorted(
        df[
            (df["budget"] > 0) & (df["revenue"] > 0) & df["roi"].notna()
            & (df["primary_genre"] != "Unknown") & df["primary_genre"].notna()
        ]["primary_genre"].unique().tolist()
    )

    with st.container(border=True):
        st.markdown('<div class="panel-title">Input Parameters</div>', unsafe_allow_html=True)
        c1, c2, c3, c4 = st.columns(4, gap="medium")
        with c1:
            budget_m = st.number_input(
                "Budget (USD millions)", min_value=0.1, max_value=500.0,
                value=50.0, step=1.0, format="%.1f", key="pred_budget",
            )
        with c2:
            default_idx = valid_genres.index("Action") if "Action" in valid_genres else 0
            genre = st.selectbox("Primary Genre", valid_genres, index=default_idx, key="pred_genre")
        with c3:
            release_month = st.selectbox(
                "Release Month", list(range(1, 13)),
                format_func=lambda m: MONTHS[m - 1], index=5, key="pred_month",
            )
        with c4:
            runtime = st.number_input(
                "Runtime (minutes)", min_value=60, max_value=240,
                value=110, step=5, key="pred_runtime",
            )
        run_btn = st.button("Run Prediction", type="primary", width="stretch")

    if not run_btn and "pred_result" not in st.session_state:
        st.markdown(
            '<div class="insight">Fill in parameters above and click '
            "<strong>Run Prediction</strong> to see forecast results.</div>",
            unsafe_allow_html=True,
        )
        return

    if run_btn:
        budget = budget_m * 1_000_000
        st.session_state["pred_result"] = predict_movie(df, budget, genre, release_month, runtime)
        st.session_state["pred_inputs"] = {
            "budget": budget, "genre": genre,
            "release_month": release_month, "runtime": runtime,
        }

    result = st.session_state["pred_result"]
    inputs = st.session_state["pred_inputs"]

    pred_revenue = result["predicted_revenue"]
    pred_roi = result["predicted_roi"]
    profit_prob = result["profit_probability"]

    prob_color = GREEN if profit_prob >= 0.6 else (AMBER if profit_prob >= 0.4 else ROSE)
    roi_color = GREEN if pred_roi >= 2.0 else (AMBER if pred_roi >= 1.0 else ROSE)

    st.markdown(
        '<div class="kpi-grid" style="grid-template-columns:repeat(3,minmax(180px,1fr));margin:.5rem 0 .8rem">'
        + _pred_kpi("Predicted Revenue", money(pred_revenue),
                    f"Range: {money(result['lower_revenue'])} – {money(result['upper_revenue'])}", TEAL)
        + _pred_kpi("Predicted ROI", f"{pred_roi:.2f}x", f"Input budget: {money(inputs['budget'])}", roi_color)
        + _pred_kpi("Profit Probability", f"{profit_prob * 100:.1f}%", "P(revenue > budget)", prob_color)
        + "</div>",
        unsafe_allow_html=True,
    )

    left, right = st.columns([0.55, 0.45], gap="medium")
    with left:
        render_chart_panel(
            "Comparable Films — Budget vs Revenue",
            _comparable_scatter(df, inputs["budget"], inputs["genre"], pred_revenue),
            f"Films with similar budget (±50%) in {inputs['genre']}. Gold star marks the prediction.",
        )
    with right:
        render_chart_panel(
            f"Historical ROI Distribution — {inputs['genre']}",
            _roi_histogram(df, inputs["genre"]),
            "Distribution of ROI for same-genre films (96th-percentile capped).",
        )

    with st.container(border=True):
        st.markdown('<div class="panel-title">Top 5 Comparable Films</div>', unsafe_allow_html=True)
        st.dataframe(_comparable_table(df, inputs["budget"], inputs["genre"]),
                     use_container_width=True, hide_index=True, height=220)
        st.markdown(
            '<div class="insight">Ranked by proximity to your input budget within the same genre.</div>',
            unsafe_allow_html=True,
        )


# ── Linear Regression Analysis ────────────────────────────────────────────────

_REG_COLS = {
    "Year": "year",
    "Budget (USD)": "budget",
    "Revenue (USD)": "revenue",
    "ROI (x)": "roi",
    "Runtime (min)": "runtime",
    "Release Month": "release_month",
    "Avg Rating": "avg_rating",
    "Vote Count": "analysis_vote_count",
}


def _linear_regression(
    df: pd.DataFrame,
    x_col: str,
    y_col: str,
    year_range: tuple[int, int],
    min_votes: int,
) -> dict:
    data = df.copy()
    data = data[(data["year"] >= year_range[0]) & (data["year"] <= year_range[1])]
    data = data[data["analysis_vote_count"].fillna(0) >= min_votes]
    data = data[[x_col, y_col]].dropna()

    if len(data) < 10:
        return {"error": f"Not enough data points ({len(data)}) after filtering. Try relaxing the filters."}

    X = data[[x_col]].values
    y = data[y_col].values
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = LinearRegression().fit(X_train, y_train)
    y_pred_all = model.predict(X)

    return {
        "coefficient": float(model.coef_[0]),
        "intercept": float(model.intercept_),
        "r2_train": float(r2_score(y_train, model.predict(X_train))),
        "r2_test": float(r2_score(y_test, model.predict(X_test))),
        "r2_all": float(r2_score(y, y_pred_all)),
        "n_samples": len(data),
        "x_values": X.flatten().tolist(),
        "y_actual": y.tolist(),
        "y_predicted": y_pred_all.tolist(),
    }


def _regression_chart(result: dict, x_label: str, y_label: str) -> go.Figure:
    x_vals = np.array(result["x_values"])
    y_actual = np.array(result["y_actual"])
    x_sorted = np.sort(x_vals)
    y_line = result["coefficient"] * x_sorted + result["intercept"]

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=x_vals, y=y_actual,
        mode="markers", name="Actual Data",
        marker=dict(size=5, color=BLUE, opacity=0.45, line=dict(width=0)),
        hovertemplate=f"{x_label}: %{{x:,.2f}}<br>{y_label}: %{{y:,.2f}}<extra></extra>",
    ))
    fig.add_trace(go.Scatter(
        x=x_sorted, y=y_line,
        mode="lines", name="Regression Line",
        line=dict(color=AMBER, width=2.5),
        hovertemplate=f"Predicted {y_label}: %{{y:,.2f}}<extra></extra>",
    ))
    fig.update_layout(**chart_layout(340))
    fig.update_xaxes(title=x_label)
    fig.update_yaxes(title=y_label)
    return fig


def render_regression_view(df: pd.DataFrame) -> None:
    from app.components import render_chart_panel

    st.markdown(
        '<div style="text-align:center;margin:0 0 1.4rem">'
        '<div style="font-size:28px;font-weight:900;color:#f7fbff;letter-spacing:-.02em;margin-bottom:.35rem">'
        "📈 Linear Regression Analysis</div>"
        '<div style="font-size:13px;color:#9aa9bd;">Explore linear relationships between movie attributes</div>'
        "</div>",
        unsafe_allow_html=True,
    )

    col_labels = list(_REG_COLS.keys())
    min_year = int(df["year"].min())
    max_year = int(df["year"].max())

    with st.container(border=True):
        st.markdown('<div class="panel-title">Regression Parameters</div>', unsafe_allow_html=True)
        c1, c2, c3, c4 = st.columns(4, gap="medium")
        with c1:
            x_label = st.selectbox("X Variable (Independent)", col_labels, index=0, key="reg_x")
        with c2:
            y_options = [k for k in col_labels if k != x_label]
            y_label = st.selectbox("Y Variable (Dependent)", y_options, index=1, key="reg_y")
        with c3:
            year_range = st.slider("Year Range", min_year, max_year, (min_year, max_year), key="reg_year")
        with c4:
            min_votes = st.number_input("Min Votes", min_value=0, max_value=1000, value=50, step=50, key="reg_votes")
        run_btn = st.button("Run Regression", type="primary", width="stretch", key="reg_btn")

    if not run_btn and "reg_result" not in st.session_state:
        st.markdown(
            '<div class="insight">Select X and Y variables above and click '
            "<strong>Run Regression</strong> to analyze the relationship.</div>",
            unsafe_allow_html=True,
        )
    else:
        if run_btn:
            x_col = _REG_COLS[x_label]
            y_col = _REG_COLS[y_label]
            if x_col == y_col:
                st.warning("X and Y must be different variables.")
            else:
                result = _linear_regression(df, x_col, y_col, year_range, min_votes)
                st.session_state["reg_result"] = result
                st.session_state["reg_labels"] = {"x": x_label, "y": y_label}

        if "reg_result" in st.session_state:
            result = st.session_state["reg_result"]
            labels = st.session_state["reg_labels"]

            if "error" in result:
                st.error(result["error"])
            else:
                r2 = result["r2_all"]
                r2_color = GREEN if r2 >= 0.5 else (AMBER if r2 >= 0.2 else ROSE)

                st.markdown(
                    '<div class="kpi-grid" style="grid-template-columns:repeat(3,minmax(180px,1fr));margin:.5rem 0 .8rem">'
                    + _pred_kpi("Slope", f"{result['coefficient']:.4f}",
                                f"Δ{labels['y']} per unit {labels['x']}", TEAL)
                    + _pred_kpi("Intercept", f"{result['intercept']:.2f}",
                                f"Baseline when {labels['x']} = 0", BLUE)
                    + _pred_kpi("R² Score", f"{r2:.3f}",
                                f"Based on {result['n_samples']:,} films", r2_color)
                    + "</div>",
                    unsafe_allow_html=True,
                )

                st.markdown(
                    f'<div class="insight" style="margin-bottom:.8rem">'
                    f'Equation: <strong>{labels["y"]} = {result["coefficient"]:.4f} × {labels["x"]} '
                    f'+ {result["intercept"]:.2f}</strong></div>',
                    unsafe_allow_html=True,
                )

                render_chart_panel(
                    f"{labels['x']} vs {labels['y']} — Linear Regression",
                    _regression_chart(result, labels["x"], labels["y"]),
                    f"R² = {r2:.3f}  ·  Train R²: {result['r2_train']:.3f}  ·  "
                    f"Test R²: {result['r2_test']:.3f}  ·  n = {result['n_samples']:,} films",
                )

    st.divider()
    render_predict_view(df)
